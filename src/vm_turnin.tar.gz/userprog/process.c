#include "userprog/process.h"

#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bitmap.h>

#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "userprog/gdt.h"
#include "userprog/pagedir.h"
#include "userprog/syscall.h"
#include "userprog/tss.h"
#include "vm/frame.h"
#include "vm/page.h"

static thread_func start_process NO_RETURN;
static bool load(const char *cmdline, void (**eip)(void), void **esp,
                 Command *current_command);
int get_total_size(Command *current_command); // self-added

/* Starts a new thread running a user program loaded from
  FILENAME.  The new thread may be scheduled (and may even exit)
  before process_execute() returns.  Returns the new process's
  thread id, or TID_ERROR if the thread cannot be created. */
tid_t process_execute(const char *file_name)
{
  char *fn_copy;
  tid_t tid;

  /* Make a copy of FILE_NAME.
     Otherwise there's a race between the caller and load(). */
  fn_copy = palloc_get_page(0);
  if (fn_copy == NULL)
    return TID_ERROR;
  strlcpy(fn_copy, file_name, PGSIZE);

  /* Create our command struct. */
  Command *current_command =
      malloc(sizeof(Command)); // changed malloc to right thing
  if (current_command == NULL)
  {
    palloc_free_page(fn_copy);
    return TID_ERROR;
  }
  current_command->fn_copy = fn_copy;
  current_command->counter = 0;

  /* Parse FILE_NAME to get the file name and arguments. */
  char *savepos;
  char *first = strtok_r(fn_copy, " ", &savepos);
  char *temp = first;
  current_command->file_name = first;

  while (temp != NULL && current_command->counter < MAX_ARGS_PER_COMMAND)
  {
    current_command->parsed_array[current_command->counter++] = temp;
    temp = strtok_r(NULL, " ", &savepos);
  }
  current_command->parsed_array[current_command->counter] = NULL;
  if (current_command->counter == 0)
  {
    palloc_free_page(fn_copy);
    free(current_command);
    return TID_ERROR;
  }

  // set child struct up
  struct status_of_child *status = malloc(sizeof(struct status_of_child));
  if (status == NULL)
  {
    palloc_free_page(fn_copy);
    free(current_command);
    return TID_ERROR;
  }

  status->exit_status = -1;
  status->count = 2;
  lock_init(&status->lock_count);
  sema_init(&status->parent, 0);

  // Synchronization needed for exec() call
  current_command->child_status = status;
  status->load = false;
  sema_init(&status->loaded, 0);

  /* Create a new thread to execute FILE_NAME. */
  tid = thread_create(current_command->file_name, PRI_DEFAULT, start_process,
                      current_command); // pass the command as it expects one
  if (tid == TID_ERROR)
  {
    palloc_free_page(fn_copy);
    free(current_command);
    free(status);
    return TID_ERROR;
  }

  // Parent waits here until child calls sema_up() in the load()
  sema_down(&status->loaded);

  // Came back from load() but executable not loaded
  if (!status->load)
  {
    lock_acquire(&status->lock_count);
    status->count--;
    bool counter = status->count == 0;
    lock_release(&status->lock_count);

    if (counter)
    {
      free(status);
    }
    return TID_ERROR;
  }

  // Child created successfully and loaded with executable
  status->tid = tid;
  list_push_back(&thread_current()->children_held, &status->elem);
  return tid;
}

/* A thread function that loads a user process and starts it
  running. */
static void start_process(void *current_command)
{
  Command *cur_command = current_command;
  char *file_name = cur_command->file_name;

  // The child thread has now been created and be assigned it own struct
  // status_of_child
  thread_current()->my_status = cur_command->child_status;

  struct intr_frame if_;
  bool success;

  /* Initialize interrupt frame and load executable. */
  memset(&if_, 0, sizeof if_);
  if_.gs = if_.fs = if_.es = if_.ds = if_.ss = SEL_UDSEG;
  if_.cs = SEL_UCSEG;
  if_.eflags = FLAG_IF | FLAG_MBS;
  success = load(file_name, &if_.eip, &if_.esp, current_command);

  /* If load failed, quit. */
  palloc_free_page(
      cur_command->fn_copy); // must free the page not the file_name which only
                             // contains the first word
  free(cur_command);

  thread_current()->my_status->load = success;
  sema_up(&thread_current()->my_status->loaded);

  // Child exits if load() not successful
  if (!success)
    thread_exit();

  /* Start the user process by simulating a return from an
     interrupt, implemented by intr_exit (in
     threads/intr-stubs.S).  Because intr_exit takes all of its
     arguments on the stack in the form of a `struct intr_frame',
     we just point the stack pointer (%esp) to our stack frame
     and jump to it. */
  asm volatile("movl %0, %%esp; jmp intr_exit" : : "g"(&if_) : "memory");
  NOT_REACHED();
}

/* Waits for thread TID to die and returns its exit status.  If
  it was terminated by the kernel (i.e. killed due to an
  exception), returns -1.  If TID is invalid or if it was not a
  child of the calling process, or if process_wait() has already
  been successfully called for the given TID, returns -1
  immediately, without waiting.


  This function will be implemented in problem 2-2.  For now, it
  does nothing. */
int process_wait(tid_t child_tid)
{
  struct list *children = &thread_current()->children_held;
  struct list_elem *elm;

  // loop through children of the process
  for (elm = list_begin(children); elm != list_end(children);
       elm = list_next(elm))
  {
    struct status_of_child *child =
        list_entry(elm, struct status_of_child, elem);
    if (child->tid == child_tid)
    {
      list_remove(elm);
      // block until the child finishes
      sema_down(&child->parent);
      int status = child->exit_status;
      lock_acquire(&child->lock_count);
      child->count--;
      bool counter = child->count == 0;
      lock_release(&child->lock_count);
      // if both parent and child are done with the PCB, free it
      if (counter)
      {
        free(child);
      }
      return status;
    }
  }
  return -1;
}

/* Free the current process's resources. */
void process_exit(void)
{
  struct thread *cur = thread_current();
  uint32_t *pd;

  // null out file descriptors and close files
  for (int i = 0; i < 128; i++)
  {
    if (cur->fd_table[i] != NULL)
    {
      lock_acquire(&lock_file);
      file_close(cur->fd_table[i]);
      lock_release(&lock_file);
      cur->fd_table[i] = NULL;
    }
  }

  lock_acquire(&lock_file);
  file_close(cur->running_file);
  lock_release(&lock_file);
  cur->running_file = NULL;

  // stores the child's PCB on a list
  while (!list_empty(&cur->children_held))
  {
    struct list_elem *elm = list_pop_front(&cur->children_held);
    struct status_of_child *child =
        list_entry(elm, struct status_of_child, elem);
    lock_acquire(&child->lock_count);

    child->count--;
    // checks whether the PCB should be freed or not
    bool counter = child->count == 0;

    lock_release(&child->lock_count);
    if (counter)
    {
      free(child);
    }
  }

  if (cur->my_status != NULL)
  {
    // cleans up its own PCB
    sema_up(&cur->my_status->parent);
    lock_acquire(&cur->my_status->lock_count);
    cur->my_status->count--;
    bool counter = cur->my_status->count == 0;
    lock_release(&cur->my_status->lock_count);
    if (counter)
    {
      free(cur->my_status);
    }
    cur->my_status = NULL;
  }

  /* Free our pages so every frame we own will leave alloc_frames
      while our page directory still exists. Eviction cannot pick one
      of our frames after page directory is destroyed. */

  hash_destroy(&cur->spt, free_spte);

  /* Destroy the current process's page directory and switch back
     to the kernel-only page directory. */
  pd = cur->pagedir;
  if (pd != NULL)
  {
    /* Correct ordering here is crucial.  We must set
       cur->pagedir to NULL before switching page directories,
       so that a timer interrupt can't switch back to the
       process page directory.  We must activate the base page
       directory before destroying the process's page
       directory, or our active page directory will be one
       that's been freed (and cleared). */
    cur->pagedir = NULL;
    pagedir_activate(NULL);
    pagedir_destroy(pd);
  }

  bitmap_destroy(cur->fd_slots);
}

/* Sets up the CPU for running user code in the current
  thread.
  This function is called on every context switch. */
void process_activate(void)
{
  struct thread *t = thread_current();

  /* Activate thread's page tables. */
  pagedir_activate(t->pagedir);

  /* Set thread's kernel stack for use in processing
     interrupts. */
  tss_update();
}

/* We load ELF binaries.  The following definitions are taken
  from the ELF specification, [ELF1], more-or-less verbatim.  */

/* ELF types.  See [ELF1] 1-2. */
typedef uint32_t Elf32_Word, Elf32_Addr, Elf32_Off;
typedef uint16_t Elf32_Half;

/* For use with ELF types in printf(). */
#define PE32Wx PRIx32 /* Print Elf32_Word in hexadecimal. */
#define PE32Ax PRIx32 /* Print Elf32_Addr in hexadecimal. */
#define PE32Ox PRIx32 /* Print Elf32_Off in hexadecimal. */
#define PE32Hx PRIx16 /* Print Elf32_Half in hexadecimal. */

/* Executable header.  See [ELF1] 1-4 to 1-8.
  This appears at the very beginning of an ELF binary. */
struct Elf32_Ehdr
{
  unsigned char e_ident[16];
  Elf32_Half e_type;
  Elf32_Half e_machine;
  Elf32_Word e_version;
  Elf32_Addr e_entry;
  Elf32_Off e_phoff;
  Elf32_Off e_shoff;
  Elf32_Word e_flags;
  Elf32_Half e_ehsize;
  Elf32_Half e_phentsize;
  Elf32_Half e_phnum;
  Elf32_Half e_shentsize;
  Elf32_Half e_shnum;
  Elf32_Half e_shstrndx;
};

/* Program header.  See [ELF1] 2-2 to 2-4.
  There are e_phnum of these, starting at file offset e_phoff
  (see [ELF1] 1-6). */
struct Elf32_Phdr
{
  Elf32_Word p_type;
  Elf32_Off p_offset;
  Elf32_Addr p_vaddr;
  Elf32_Addr p_paddr;
  Elf32_Word p_filesz;
  Elf32_Word p_memsz;
  Elf32_Word p_flags;
  Elf32_Word p_align;
};

/* Values for p_type.  See [ELF1] 2-3. */
#define PT_NULL 0           /* Ignore. */
#define PT_LOAD 1           /* Loadable segment. */
#define PT_DYNAMIC 2        /* Dynamic linking info. */
#define PT_INTERP 3         /* Name of dynamic loader. */
#define PT_NOTE 4           /* Auxiliary info. */
#define PT_SHLIB 5          /* Reserved. */
#define PT_PHDR 6           /* Program header table. */
#define PT_STACK 0x6474e551 /* Stack segment. */

/* Flags for p_flags.  See [ELF3] 2-3 and 2-4. */
#define PF_X 1 /* Executable. */
#define PF_W 2 /* Writable. */
#define PF_R 4 /* Readable. */

static bool setup_stack(void **esp, Command *current_command);
static bool validate_segment(const struct Elf32_Phdr *, struct file *);
static bool load_segment(struct file *file, off_t ofs, uint8_t *upage,
                         uint32_t read_bytes, uint32_t zero_bytes,
                         bool writable);

/* Loads an ELF executable from FILE_NAME into the current thread.
  Stores the executable's entry point into *EIP
  and its initial stack pointer into *ESP.
  Returns true if successful, false otherwise. */
bool load(const char *file_name, void (**eip)(void), void **esp,
          Command *current_command)
{
  struct thread *t = thread_current();
  struct Elf32_Ehdr ehdr;
  struct file *file = NULL;
  off_t file_ofs;
  bool success = false;
  int i;

  lock_acquire(&lock_file);

  /* Allocate and activate page directory. */
  t->pagedir = pagedir_create();
  if (t->pagedir == NULL)
  {
    lock_release(&lock_file);
    goto done;
  }
  process_activate();

  /* Open executable file. */
  file = filesys_open(file_name);
  if (file == NULL)
  {
    lock_release(&lock_file);
    printf("load: %s: open failed\n", file_name);
    goto done;
  }

  // "Locking" the executable
  file_deny_write(file);
  lock_release(&lock_file);

  /* Read and verify executable header. */
  if (file_read(file, &ehdr, sizeof ehdr) != sizeof ehdr ||
      memcmp(ehdr.e_ident, "\177ELF\1\1\1", 7) || ehdr.e_type != 2 ||
      ehdr.e_machine != 3 || ehdr.e_version != 1 ||
      ehdr.e_phentsize != sizeof(struct Elf32_Phdr) || ehdr.e_phnum > 1024)
  {
    printf("load: %s: error loading executable\n", file_name);
    goto done;
  }

  /* Read program headers. */
  file_ofs = ehdr.e_phoff;
  for (i = 0; i < ehdr.e_phnum; i++)
  {
    struct Elf32_Phdr phdr;

    if (file_ofs < 0 || file_ofs > file_length(file))
      goto done;
    file_seek(file, file_ofs);

    if (file_read(file, &phdr, sizeof phdr) != sizeof phdr)
      goto done;
    file_ofs += sizeof phdr;
    switch (phdr.p_type)
    {
    case PT_NULL:
    case PT_NOTE:
    case PT_PHDR:
    case PT_STACK:
    default:
      /* Ignore this segment. */
      break;
    case PT_DYNAMIC:
    case PT_INTERP:
    case PT_SHLIB:
      goto done;
    case PT_LOAD:
      if (validate_segment(&phdr, file))
      {
        bool writable = (phdr.p_flags & PF_W) != 0;
        uint32_t file_page = phdr.p_offset & ~PGMASK;
        uint32_t mem_page = phdr.p_vaddr & ~PGMASK;
        uint32_t page_offset = phdr.p_vaddr & PGMASK;
        uint32_t read_bytes, zero_bytes;
        if (phdr.p_filesz > 0)
        {
          /* Normal segment.
             Read initial part from disk and zero the rest. */
          read_bytes = page_offset + phdr.p_filesz;
          zero_bytes =
              (ROUND_UP(page_offset + phdr.p_memsz, PGSIZE) - read_bytes);
        }
        else
        {
          /* Entirely zero.
             Don't read anything from disk. */
          read_bytes = 0;
          zero_bytes = ROUND_UP(page_offset + phdr.p_memsz, PGSIZE);
        }

        if (!load_segment(file, file_page, (void *)mem_page, read_bytes,
                          zero_bytes, writable))
          goto done;
      }
      else
        goto done;
      break;
    }
  }

  /* Set up stack. */
  if (!setup_stack(esp, current_command))
    goto done;

  /* Start address. */
  *eip = (void (*)(void))ehdr.e_entry;

  success = true;

done:
  /* We arrive here whether the load is successful or not. */
  if (success)
  {
    thread_current()->running_file = file;
  }
  else
  {
    file_close(file);
  }

  return success;
}

/* load() helpers. */

static bool install_page(void *upage, void *kpage, bool writable);

/* Checks whether PHDR describes a valid, loadable segment in
  FILE and returns true if so, false otherwise. */
static bool validate_segment(const struct Elf32_Phdr *phdr, struct file *file)
{
  /* p_offset and p_vaddr must have the same page offset. */
  if ((phdr->p_offset & PGMASK) != (phdr->p_vaddr & PGMASK))
    return false;

  /* p_offset must point within FILE. */
  if (phdr->p_offset > (Elf32_Off)file_length(file))
    return false;

  /* p_memsz must be at least as big as p_filesz. */
  if (phdr->p_memsz < phdr->p_filesz)
    return false;

  /* The segment must not be empty. */
  if (phdr->p_memsz == 0)
    return false;

  /* The virtual memory region must both start and end within the
     user address space range. */
  if (!is_user_vaddr((void *)phdr->p_vaddr))
    return false;
  if (!is_user_vaddr((void *)(phdr->p_vaddr + phdr->p_memsz)))
    return false;

  /* The region cannot "wrap around" across the kernel virtual
     address space. */
  if (phdr->p_vaddr + phdr->p_memsz < phdr->p_vaddr)
    return false;

  /* Disallow mapping page 0.
     Not only is it a bad idea to map page 0, but if we allowed
     it then user code that passed a null pointer to system calls
     could quite likely panic the kernel by way of null pointer
     assertions in memcpy(), etc. */
  if (phdr->p_vaddr < PGSIZE)
    return false;

  /* It's okay. */
  return true;
}

/* Loads a segment starting at offset OFS in FILE at address
  UPAGE.  In total, READ_BYTES + ZERO_BYTES bytes of virtual
  memory are initialized, as follows:


       - READ_BYTES bytes at UPAGE must be read from FILE
         starting at offset OFS.


       - ZERO_BYTES bytes at UPAGE + READ_BYTES must be zeroed.


  The pages initialized by this function must be writable by the
  user process if WRITABLE is true, read-only otherwise.


  Return true if successful, false if a memory allocation error
  or disk read error occurs. */
static bool load_segment(struct file *file, off_t ofs, uint8_t *upage,
                         uint32_t read_bytes, uint32_t zero_bytes,
                         bool writable)
{
  ASSERT((read_bytes + zero_bytes) % PGSIZE == 0);
  ASSERT(pg_ofs(upage) == 0);
  ASSERT(ofs % PGSIZE == 0);

  while (read_bytes > 0 || zero_bytes > 0)
  {
    /* Calculate how to fill this page.
       We will read PAGE_READ_BYTES bytes from FILE
       and zero the final PAGE_ZERO_BYTES bytes. */
    size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
    size_t page_zero_bytes = PGSIZE - page_read_bytes;

    /* Lazy loading by creating spt entries */
    struct spt_entry *spte = spte_init((void *)upage, writable, ofs, page_read_bytes,
                                       page_zero_bytes, file);
    if (!spte)
    {
      free(spte);
      return false;
    }

    spte->is_loaded = false;
    spte->file_backed = true;
    spte->swapped = false;
    spte->all_zero = (page_read_bytes == 0);

    hash_insert(&thread_current()->spt, &spte->hash_elem);

    /* Advance. */
    read_bytes -= page_read_bytes;
    zero_bytes -= page_zero_bytes;
    ofs += page_read_bytes;
    upage += PGSIZE;
  }

  return true;
}

/* Create a minimal stack by mapping a zeroed page at the top of
  user virtual memory. */
static bool setup_stack(void **esp, Command *current_command)
{
  bool success = false;

  // Adding the initial stack page to the spt
  struct spt_entry *spte = spte_init(((uint8_t *)PHYS_BASE) - PGSIZE, true, 0, 0, 0, NULL);
  if (!spte)
  {
    free(spte);
    return false;
  }

  spte->file_backed = false;
  spte->swapped = false;
  spte->all_zero = true;

  struct ft_entry *frame = frame_alloc(thread_current(), spte, true);
  if (!frame)
  {
    free(spte);
    return false;
  }

  hash_insert(&thread_current()->spt, &spte->hash_elem);

  success = install_page(((uint8_t *)PHYS_BASE) - PGSIZE, frame->kvaddr, true);
  if (!success)
  {
    free_frame(spte);
    return false;
  }

  spte->is_loaded = true;

  // Setting up the stack
  *esp = PHYS_BASE;

  int total_size = get_total_size(current_command);
  int word_align = 0;
  while ((total_size + word_align) % 4 != 0)
  {
    word_align++;
  }
  if (total_size + word_align > PGSIZE)
  {
    return false;
  }

  // put the strings on the stack
  for (int i = current_command->counter - 1; i >= 0; --i)
  {
    int length = strlen(current_command->parsed_array[i]) + 1;
    *esp = (char *)*esp - length;
    strlcpy(*esp, current_command->parsed_array[i], length);
    current_command->parsed_array[i] = *esp;
  }

  // put word_align 0s on the stack
  for (int i = 0; i < word_align; ++i)
  {
    *esp = (char *)*esp - 1;
    *(char *)*esp = 0;
  }

  // put the pointers to the strings on the stack
  for (int i = current_command->counter; i >= 0; --i)
  {
    *esp = (char *)*esp - 4;
    *(char **)*esp = current_command->parsed_array[i];
  }

  // put the metadata (argv pointer, argc, and the return address) on the
  // stack
  char **argv_addr = *esp;
  *esp = (char *)*esp - 4;
  *(char ***)*esp = argv_addr;
  *esp = (char *)*esp - 4;
  *(int *)*esp = current_command->counter;
  *esp = (char *)*esp - 4;
  *(int *)*esp = 0;

  lock_acquire(&frame_lock);
  frame->locked = false;
  lock_release(&frame_lock);

  return true;
  // hex_dump((uintptr_t)*esp, *esp, (char *)PHYS_BASE - (char *)*esp, true);
}

/**
 * Calculates total length of arguments in an array (excluding the bytes of
 * word_align for 16B alignment.)
 */
int get_total_size(Command *current_command)
{
  char *temp = current_command->parsed_array[0];
  int i = 0;
  size_t sum = 0;

  while (temp != NULL)
  {
    sum += strlen(temp) + 1 + 4;
    temp = current_command->parsed_array[++i];
  }
  sum += 16;
  return sum;
}

/* Adds a mapping from user virtual address UPAGE to kernel
  virtual address KPAGE to the page table.
  If WRITABLE is true, the user process may modify the page;
  otherwise, it is read-only.
  UPAGE must not already be mapped.
  KPAGE should probably be a page obtained from the user pool
  with palloc_get_page().
  Returns true on success, false if UPAGE is already mapped or
  if memory allocation fails. */
static bool install_page(void *upage, void *kpage, bool writable)
{
  struct thread *t = thread_current();

  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  return (pagedir_get_page(t->pagedir, upage) == NULL &&
          pagedir_set_page(t->pagedir, upage, kpage, writable));
}
